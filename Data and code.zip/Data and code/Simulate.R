library(randomForest)
library(caret)
library(pROC)
library(PRROC)


data <- read.csv("F:\\data_Ageratina\\Simulate\\Data\\Data.csv")
summary(data)
names(data) <- c('X',	'Y',	'Year',	'bio_11',	'bio_15',	'bio_19','bio_2',	'bio_3',	'bio_4',	'Dem',	'Cropland',	'Pop',	'Point')


env_vars <- data[, 4:12]

）
species_presence <- data[, 13]


species_presence_factor <- as.factor(ifelse(species_presence > 0, 1, 0))


model_data <- data.frame(env_vars, species_presence_factor)

train_and_save_model <- function(train_data, model_index) {

  set.seed(123 + model_index) 
  train_index <- createDataPartition(train_data$species_presence_factor, p = 0.75, list = FALSE)
  train_data_split <- train_data[train_index, ]
  test_data_split <- train_data[-train_index, ]
  

  rf_model <- randomForest(species_presence_factor ~ ., data = train_data_split, importance = TRUE, ntree = 100)
  

  test_probabilities <- predict(rf_model, newdata = test_data_split, type = "prob")[, "1"]
  test_predictions <- ifelse(test_probabilities > 0.5, 1, 0)
  test_predictions <- factor(test_predictions, levels = levels(test_data_split$species_presence_factor))
  

  f1 <- F_meas(data = test_predictions, reference = test_data_split$species_presence_factor)
  

  roc_obj <- roc(test_data_split$species_presence_factor, test_probabilities)
  roc_auc <- auc(roc_obj)
  

  pr_obj <- pr.curve(scores.class0 = test_probabilities, weights.class0 = as.numeric(test_data_split$species_presence_factor) - 1, curve = TRUE)
  pr_auc <- pr_obj$auc.integral
  

  save(rf_model, file = paste0("F:\\data_Ageratina\\Simulate\\Model\\rf_model_", model_index, ".Rdata"))
  

  all_predictions <- predict(rf_model, newdata = train_data, type = "prob")
  

  data_with_predictions <- cbind(train_data, Probability = all_predictions[, "1"])
  

  write.csv(data_with_predictions, paste0("F:\\data_Ageratina\\Simulate\\Product\\all_results_", model_index, ".csv"), row.names = FALSE)
  
  return(c(f1, roc_auc, pr_auc))
}


num_iterations <- 50
results <- matrix(NA, nrow = num_iterations, ncol = 3)
colnames(results) <- c("F1_Score", "ROC_AUC", "PR_AUC")

for (i in 1:num_iterations) {
  results[i, ] <- train_and_save_model(model_data, i)
  cat("Model", i, "F1-Score:", results[i, 1], "ROC-AUC:", results[i, 2], "PR-AUC:", results[i, 3], "\n")  
}


write.csv(results, "F:\\data_Ageratina\\Simulate\\Table\\model_metrics.csv", row.names = FALSE)
